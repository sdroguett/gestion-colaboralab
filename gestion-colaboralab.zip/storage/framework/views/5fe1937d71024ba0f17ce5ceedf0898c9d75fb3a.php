<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<style>
    .box {
        display: none;
        width: 100%;
    }

    a:hover+.box,
    .box:hover {
        display: block;
        position: relative;
        z-index: 100;
    }
</style>

        <div class="container-fluid">
            <div class="fade-in">
              <div class="card">
                <div class="card-header"> Contactados
                                  <div class="card-header-actions"><a class="card-header-action" href="https://datatables.net" target="_blank"><small class="text-muted">docs</small></a></div>

                </div>

                <div class="card-body">
                  <table class="table table-striped table-bordered datatable">
                    <thead>
                      <tr>
                      <th>Id</th>
                            <th>Nombre</th>
                            <th>Paterno</th>
                            <th>Materno</th>
                            <th>Comentarios</th>
                            <th>Base</th>
                            <th>Estado</th>
                            <th>Ver</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                      <td><?php echo e($contacto->cont_id); ?></td>
                            <td><?php echo e($contacto->nombre); ?></td>
                            <td><?php echo e($contacto->paterno); ?></td>
                            <td><?php echo e($contacto->materno); ?></td>
                            <td><a><?php echo e(substr($contacto->comentarios,0,20)); ?>...</a>
                            <div class="box">
                            <?php echo e($contacto->comentarios); ?>

                            </div>
                            </td>
                            <td><?php echo e($contacto->base); ?></td>
                            <td><?php echo e($contacto->descripcion); ?></td>


                        <td style="text-align:center">
                        <a class="btn btn-success" href="<?php echo e(route('contacto.modificar',[$contacto])); ?>">
                         <svg class="c-icon">
                              <use xlink:href="/assets/icons/coreui/free-symbol-defs.svg#cui-magnifying-glass"></use>
                            </svg>
                            </a></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>


<div class="modal fade" id="eliminarModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title">Eliminar Contacto</h4>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                  </div>
                  <div class="modal-body">
                    <p>Esta seguro que desea eliminar?</p>
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>

                    <a class="btn btn-primary" type="submit" href="#">Eliminar</a>

                  </div>
                </div>
                <!-- /.modal-content-->
              </div>
              <!-- /.modal-dialog-->
            </div>








<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('js/jquery.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatables.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('coreui.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\EasyPHP-Devserver-17\eds-www\gestion-colaboralab\resources\views/menu/contactados.blade.php ENDPATH**/ ?>