<footer class="c-footer">
 <div><a href="https://colaboralab.cl">ColaboraLab</a> &copy; 2020.</div>
 <!-- <div class="ml-auto"><a href="https://colaboralab.cl">ColaboraLab</a> &copy; 2020 .</div></div>-->
</footer>
<?php /**PATH C:\EasyPHP-Devserver-17\eds-www\cl-gestion\resources\views/coreui/shared/footer.blade.php ENDPATH**/ ?>